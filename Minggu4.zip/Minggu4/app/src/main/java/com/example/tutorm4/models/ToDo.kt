package com.example.tutorm4.models

data class ToDo(
    var task: String,
    var status: Boolean
)
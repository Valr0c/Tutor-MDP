package com.example.tutorminggu6

data class Skill (var name:String, var damage:Int, var mana:Int)
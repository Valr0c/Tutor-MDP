package com.example.minggu2

interface HewanAir {
    fun berenang(): String
}

interface HewanDarat {
    fun bersuara(): String
}